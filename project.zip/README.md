# AI-Powered Intelligent News Analytics Platform

An intelligent news analytics system that proactively surfaces emerging trends and generates intelligence without requiring user queries.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                      DATA SOURCES                                │
│   RSS Feeds │ NewsAPI │ Web Crawlers                            │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────────┐
│                   INGESTION LAYER                               │
│   Fetcher → Redis Streams → NLP Workers                         │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────────┐
│              CANONICAL STORE (Supabase/PostgreSQL)              │
│   Articles │ Entities │ Keyphrases ||──────────────────────┬──────────────────────────────┘
                       │
          ┌────────────┴────────────┐
          ▼                         ▼
┌──────────────────┐     ┌───────────────────────┐
│  ELASTICSEARCH   │     │    VECTOR INDEX       │
│  BM25 + kNN      │     │  (ES dense_vector)    │
└────────┬─────────┘     └──────────┬────────────┘
         └──────────┬───────────────┘
                    ▼
┌─────────────────────────────────────────────────────────────────┐
│            HYBRID RETRIEVAL + RERANKING                         │
│   BM25 + kNN → RRF Fusion → Cross-Encoder Reranker             │
└────────────────────────────┬────────────────────────────────────┘
                             │
         ┌───────────────────┼──────────────────┐
         ▼                   ▼                  ▼
┌────────────────┐  ┌─────────────────┐  ┌─────────────────────┐
│  SEARCH API    │  │  TEMPORAL       │  │  PROACTIVE          │
│  (FastAPI)     │  │  ANALYTICS      │  │  INTELLIGENCE       │
│                │  │                 │  │  ENGINE             │
│ /search        │  │ Spike detect    │  │ Emergence Detector  │
│ /intelligence  │  │ Trend engine    │  │ Narrative Monitor   │
│ /agent         │  │ Daily digest    │  │ Feed Generator      │
└────────────────┘  └─────────────────┘  └─────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                      FRONTEND (React)                           │
│  Intelligence Feed │ Search │ Trending │ AI Analyst             │
└─────────────────────────────────────────────────────────────────┘
```

## Prerequisites

### Required Services

1. **Supabase (PostgreSQL)** - Already provisioned, credentials in `.env`
2. **Redis** - Message queue and caching
3. **Elasticsearch 8.x** - Full-text search and vector index
4. **Python 3.11+** - Backend runtime
5. **Node.js 18+** - Frontend runtime

### API Keys (Optional)

- **Groq API Key** - LLM for synthesis and reasoning
- **NewsAPI Key** - Additional news sources

## Quick Start

### Step 1: Configure Backend Environment

The Supabase credentials are already configured in `backend/.env`. You don't need to access the Supabase dashboard - everything is pre-configured!

Just copy the file:
```bash
cp backend/.env.example backend/.env
# The credentials are already filled in - no changes needed!
```

### Step 2: Start Infrastructure Services

```bash
# Start Redis (Docker)
docker run -d --name redis -p 6379:6379 redis:7-alpine

# Start Elasticsearch (Docker) - wait 30 seconds for it to initialize
docker run -d --name elasticsearch \
  -p 9200:9200 \
  -e "discovery.type=single-node" \
  -e "xpack.security.enabled=false" \
  -e "ES_JAVA_OPTS=-Xms1g -Xmx1g" \
  docker.elastic.co/elasticsearch/elasticsearch:8.12.0
```

### Step 3: Backend Setup

```bash
# Create Python virtual environment
cd backend
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Download spaCy model (for NER)
python -m spacy download en_core_web_lg
```

### Step 4: Start Backend Services

Open multiple terminal windows:

**Terminal 1 - FastAPI Server:**
```bash
cd backend
source venv/bin/activate  # On Windows: venv\Scripts\activate
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

**Terminal 2 - NLP Worker (optional, for processing articles):**
```bash
cd backend
source venv/bin/activate
python -m app.workers.nlp_worker worker-1
```

**Terminal 3 - Ingest News (from RSS feeds):**
```bash
curl -X POST http://localhost:8000/ingest/fetch
```

### Step 5: Start Frontend

```bash
# In project root
npm install
npm run dev
```

The frontend will be available at `http://localhost:5173`

## API Endpoints

### Search
- `POST /search` - Hybrid search with reranking
- `GET /search/keyword` - BM25-only search
- `GET /search/semantic` - Vector-only search
- `GET /search/similar/{article_id}` - Find similar articles

### Intelligence
- `GET /intelligence/feed` - Proactive intelligence feed (zero-query)
- `POST /intelligence/feed/generate` - Manually generate feed
- `GET /intelligence/trending` - Trending entities by velocity
- `GET /intelligence/digest` - Daily news digest
- `GET /intelligence/entity/{name}/trend` - Entity trend analysis
- `GET /intelligence/volume` - Volume over time

### Agent
- `POST /agent/timeline` - Generate event timeline
- `POST /agent/explain-trend` - Explain why topic is trending
- `POST /agent/ask` - General analyst query

### Articles
- `GET /articles/{id}` - Get article by ID
- `GET /articles/` - List articles with filters
- `GET /articles/recent` - Recent articles
- `GET /articles/stats` - Database statistics

### Ingestion
- `POST /ingest/fetch` - Fetch from RSS feeds
- `POST /ingest/process` - Process pending articles

## Frontend Features

### Intelligence Feed (Landing Page)
Zero-query homepage showing proactively generated intelligence:
- Emerging topic detection
- Narrative shift alerts
- Entity spotlights

### Search
- Hybrid search combining keyword and semantic retrieval
- Filter by category, source, date range
- Sentiment indicators on results

### Trending
- Entities ranked by velocity (rate of change)
- Sentiment visualization
- Article counts

### AI Analyst
- Timeline generation for entities/topics
- Trend explanation with supporting evidence
- LangGraph-powered multi-step reasoning

## Proactive Intelligence Engine

The PIE runs on schedule without user interaction:

1. **Emergence Detector** (every 30 min)
   - Clusters recent articles by embedding similarity
   - Compares against 48-hour centroid history
   - Flags genuinely new topic clusters

2. **Narrative Monitor** (every hour)
   - Tracks sentiment for monitored entities
   - Detects sentiment shifts and reversals
   - Identifies narrative divergence across sources

3. **Feed Generator** (6 AM and 6 PM)
   - Aggregates detected signals
   - Scores by novelty, reach, urgency
   - Generates LLM summaries
   - Writes to Redis feed

## Development

### Running Tests
```bash
# Backend
cd backend
pytest

# Frontend
npm run test
```

### Type Checking
```bash
# Frontend
npm run typecheck
```

### Linting
```bash
# Frontend
npm run lint

# Backend
ruff check app/
```

## Project Structure

```
project/
├── backend/
│   ├── app/
│   │   ├── agents/          # LangGraph workflows
│   │   ├── routers/         # FastAPI endpoints
│   │   ├── services/        # Business logic
│   │   ├── utils/           # Database, ES, Redis clients
│   │   ├── workers/         # Background workers
│   │   ├── config.py        # Settings
│   │   └── main.py          # FastAPI app
│   └── requirements.txt
├── src/
│   ├── App.tsx              # Main React app
│   └── main.tsx
├── supabase/
│   └── migrations/          # Database schema
└── README.md
```

## Key Technologies

| Layer | Technology |
|-------|------------|
| Frontend | React + TypeScript + Tailwind |
| Backend | FastAPI + Python 3.11 |
| Database | Supabase (PostgreSQL + pgvector) |
| Search | Elasticsearch 8.12 (BM25 + kNN) |
| Queue | Redis Streams |
| NLP | spaCy + sentence-transformers |
| LLM | Groq (Llama 3.1) |
| Agents | LangGraph |

## Troubleshooting

### Elasticsearch won't start
```bash
# Increase vm.max_map_count (Linux)
sudo sysctl -w vm.max_map_count=262144
```

### Redis connection refused
```bash
# Check Redis is running
docker ps | grep redis
docker start redis
```

### Database connection issues
Check that Supabase credentials in `.env` match the project `.env` file.

### NLP worker memory issues
Reduce batch size or use a smaller embedding model:
```python
# In config.py
embedding_model = "all-MiniLM-L6-v2"  # 384 dims, faster
```

## License

MIT License - Intern MVP Project
